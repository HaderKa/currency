﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;

namespace yahoo
{
    class Program
    {
        static void Main(string[] args)
        {
            string csvData;
            string from_currency = "EUR";
            string to_currency = "USD";
            double amount = 5.64;
            double exchange = 0;

            using (WebClient web = new WebClient())
            {
                csvData = web.DownloadString("http://download.finance.yahoo.com/d/quotes?f=sl1d1t1&s="+from_currency+to_currency+"=X");
            }

            List<Price> prices = YahooFinance.Parse(csvData);

            foreach (Price price in prices)
            {
                Console.WriteLine(string.Format("Currencies: {0}, exchange Course: {1}, Date: {2}, Time: {3} ", price.Name, price.Course, price.Date, price.Time ));
                exchange = amount * price.Course;
                //double test = double.Parse(price.Course);
               // Console.WriteLine(test);

            }
            
            Console.WriteLine("{0} {1} are  {2} {3}", amount, from_currency, exchange, to_currency);

            Console.Read();
    }
    }
    public static class YahooFinance
    {
        public static List<Price> Parse(string csvData)
        {
            List<Price> prices = new List<Price>();

            string[] rows = csvData.Replace("\r", "").Split('\n');

            foreach (string row in rows)
            {
                if (string.IsNullOrEmpty(row)) continue;

                string[] cols = row.Split(',');

                Price p = new Price();
                //p.Symbol = cols[0];
                p.Name = cols[0];
                p.Course = Convert.ToDouble(cols[1])/10000;
                p.Date = cols[2];
                p.Time = cols[3];
                //p.Bid = Convert.ToDecimal(cols[2]);
                //p.Ask = Convert.ToDecimal(cols[3]);
                //p.Open = Convert.ToDecimal(cols[4]);
                //p.PreviousClose = Convert.ToDecimal(cols[5]);
                //p.Last = Convert.ToDecimal(cols[6]);

                prices.Add(p);
            }

            return prices;
        }
    }

    public class Price
    {
        public string Name { get; set; }
        public double Course { get; set; }

        public string Date { get; set; }
        public string Time { get; set; }
    }
      


}
